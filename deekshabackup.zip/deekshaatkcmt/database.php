
<?php
$con = mysqli_connect("localhost", "ourwebpr_dk", "1u0lATw[*8dx", "ourwebpr_deeksha") or die("Query Not Run");
?>